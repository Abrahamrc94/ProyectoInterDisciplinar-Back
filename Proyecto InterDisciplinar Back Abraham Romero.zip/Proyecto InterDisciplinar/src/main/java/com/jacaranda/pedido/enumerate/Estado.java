package com.jacaranda.pedido.enumerate;

public enum Estado {
	RECIBIDO, EN_PREPARACION, PENDIENTE, EN_REPARTO, ENTREGADO, CANCELADO
}
